import fs from 'fs';
import path from 'path';

const distDir = path.resolve('dist');
const rootDir = path.resolve('.');

if (!fs.existsSync(distDir)) {
  console.error('Dist directory does not exist. Run npm run build first.');
  process.exit(1);
}

// Copy dist files that GitHub Pages expects at root
const itemsToCopy = [
  'CNAME',
  'robots.txt',
  'sitemap.xml',
  'assets',
];

itemsToCopy.forEach((item) => {
  const src = path.join(distDir, item);
  const dest = path.join(rootDir, item);
  if (fs.existsSync(src)) {
    fs.cpSync(src, dest, { recursive: true, force: true });
    console.log(`Copied ${item} to root`);
  }
});

console.log('Sync complete. Root assets are updated for production deployment.');
