/**
 * Astral Precision Motion & Interaction Engine
 * Handles magnetic interactions, card spotlight illumination, 3D card tilt,
 * staggered typography reveals, scroll choreography, and numerical counters.
 */

export function initMotionSystem() {
  // Check for reduced motion preference
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  // 1. Card Spotlight & 3D Interactive Tilt
  initCardSpotlights(prefersReducedMotion);

  // 2. Magnetic Buttons & Controls
  if (!prefersReducedMotion && window.innerWidth > 960) {
    initMagneticButtons();
  }

  // 3. Staggered Typography & Scroll Reveals
  initScrollReveals();

  // 4. Numerical Telemetry Counters
  initNumberCounters();

  // 5. Architectural Ambient Cursor (Desktop only)
  if (!prefersReducedMotion && window.innerWidth > 1024 && !('ontouchstart' in window)) {
    initArchitecturalCursor();
  }
}

/**
 * Spatial mouse glow and subtle 3D tilt on cards
 */
function initCardSpotlights(prefersReducedMotion) {
  const cards = document.querySelectorAll('.arch-card, .bot-terminal-card, .price-estimator-box, .cf-security-card, .ticket-preview-box');

  cards.forEach((card) => {
    card.addEventListener('pointermove', (e) => {
      const rect = card.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;

      // Update CSS variables for radial glow
      card.style.setProperty('--mouse-x', `${x}px`);
      card.style.setProperty('--mouse-y', `${y}px`);

      if (!prefersReducedMotion) {
        // Subtle 3D perspective tilt
        const centerX = rect.width / 2;
        const centerY = rect.height / 2;
        const rotateX = ((y - centerY) / centerY) * -3.5;
        const rotateY = ((x - centerX) / centerX) * 3.5;

        card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-2px)`;
      }
    });

    card.addEventListener('pointerleave', () => {
      if (!prefersReducedMotion) {
        card.style.transform = '';
      }
    });
  });
}

/**
 * Magnetic button interaction for key CTAs
 */
function initMagneticButtons() {
  const magneticEls = document.querySelectorAll('.btn-primary, .header-cta, .control-pill, .magnetic-target');

  magneticEls.forEach((el) => {
    let boundRect = null;

    const onEnter = () => {
      boundRect = el.getBoundingClientRect();
    };

    const onMove = (e) => {
      if (!boundRect) boundRect = el.getBoundingClientRect();
      const x = e.clientX - boundRect.left - boundRect.width / 2;
      const y = e.clientY - boundRect.top - boundRect.height / 2;

      // Magnetic pull factor (restrained and subtle)
      const pullX = x * 0.22;
      const pullY = y * 0.22;

      el.style.transform = `translate(${pullX}px, ${pullY}px)`;
    };

    const onLeave = () => {
      el.style.transform = 'translate(0px, 0px)';
      boundRect = null;
    };

    el.addEventListener('pointerenter', onEnter);
    el.addEventListener('pointermove', onMove);
    el.addEventListener('pointerleave', onLeave);
  });
}

/**
 * Scroll triggered staggered reveals using IntersectionObserver
 */
function initScrollReveals() {
  const elements = document.querySelectorAll('.reveal-on-scroll, .arch-card, .process-stage-item, .section-header');

  const observer = new IntersectionObserver((entries, obs) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-revealed');
        obs.unobserve(entry.target);
      }
    });
  }, {
    threshold: 0.12,
    rootMargin: '0px 0px -40px 0px'
  });

  elements.forEach((el, index) => {
    if (!el.classList.contains('is-revealed')) {
      el.style.setProperty('--reveal-delay', `${(index % 4) * 0.1}s`);
      observer.observe(el);
    }
  });
}

/**
 * Smooth animated numerical counters for metrics
 */
function initNumberCounters() {
  const counterEls = document.querySelectorAll('[data-counter]');

  const observer = new IntersectionObserver((entries, obs) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        const el = entry.target;
        const targetValue = parseFloat(el.getAttribute('data-counter'));
        const prefix = el.getAttribute('data-prefix') || '';
        const suffix = el.getAttribute('data-suffix') || '';
        const duration = 1400; // ms
        const startTime = performance.now();

        const animateCount = (now) => {
          const elapsed = now - startTime;
          const progress = Math.min(elapsed / duration, 1);
          // Ease out cubic
          const eased = 1 - Math.pow(1 - progress, 3);
          const current = Math.floor(targetValue * eased);

          el.textContent = `${prefix}${current.toLocaleString()}${suffix}`;

          if (progress < 1) {
            requestAnimationFrame(animateCount);
          } else {
            el.textContent = `${prefix}${targetValue.toLocaleString()}${suffix}`;
          }
        };

        requestAnimationFrame(animateCount);
        obs.unobserve(el);
      }
    });
  }, { threshold: 0.2 });

  counterEls.forEach((el) => observer.observe(el));
}

/**
 * Architectural ambient pointer halo
 */
function initArchitecturalCursor() {
  // Prevent duplicate cursors
  if (document.querySelector('.ambient-cursor-halo')) return;

  const cursorHalo = document.createElement('div');
  cursorHalo.className = 'ambient-cursor-halo';
  document.body.appendChild(cursorHalo);

  let mouseX = -100;
  let mouseY = -100;
  let haloX = -100;
  let haloY = -100;

  window.addEventListener('pointermove', (e) => {
    mouseX = e.clientX;
    mouseY = e.clientY;
  }, { passive: true });

  const loop = () => {
    haloX += (mouseX - haloX) * 0.15;
    haloY += (mouseY - haloY) * 0.15;

    cursorHalo.style.transform = `translate3d(${haloX}px, ${haloY}px, 0)`;
    requestAnimationFrame(loop);
  };
  requestAnimationFrame(loop);

  // Expand halo on interactive elements
  const interactives = document.querySelectorAll('a, button, input, select, textarea, .control-pill, .arch-card');
  interactives.forEach((el) => {
    el.addEventListener('pointerenter', () => cursorHalo.classList.add('is-hovering'));
    el.addEventListener('pointerleave', () => cursorHalo.classList.remove('is-hovering'));
  });
}
