/**
 * Interactive Discord Bot System Simulator
 * Demonstrates Astral's bespoke slash command execution, gateway latency, and event pipelines.
 */
export function initDiscordSimulator(containerId) {
  const container = document.getElementById(containerId);
  if (!container) return;

  container.innerHTML = `
    <div class="bot-terminal-card">
      <div class="bot-terminal-header">
        <div class="bot-status-indicator">
          <span class="bot-dot"></span>
          <span class="bot-name">ASTRAL CORE NODE</span>
          <span class="bot-tag">v2.4.1</span>
        </div>
        <div class="bot-telemetry">
          <span class="telemetry-item">GATEWAY: <strong id="gw-latency">18ms</strong></span>
          <span class="telemetry-item">UPTIME: <strong>99.98%</strong></span>
        </div>
      </div>

      <div class="bot-terminal-body" id="bot-message-log">
        <div class="bot-msg-row">
          <div class="bot-avatar">A</div>
          <div class="bot-msg-content">
            <div class="bot-msg-author">Astral <span class="badge-app">APP</span> <span class="bot-msg-time">Today at 14:30</span></div>
            <div class="bot-embed">
              <div class="embed-sidebar"></div>
              <div class="embed-inner">
                <div class="embed-title">Operational Status · Cluster [eu-central-01]</div>
                <div class="embed-desc">All shard connections stable. Automated queue dispatcher listening on socket #6102.</div>
                <div class="embed-fields">
                  <div class="embed-field"><div class="ef-label">ACTIVE GUILDS</div><div class="ef-val">48 Communities</div></div>
                  <div class="embed-field"><div class="ef-label">PIPELINE</div><div class="ef-val">0 Tasks Queued</div></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="bot-actions-bar">
        <button type="button" class="bot-btn-action" id="btn-action-audit">
          <span class="icon-pulse"></span> /run-audit
        </button>
        <button type="button" class="bot-btn-action" id="btn-action-ticket">
          <span class="icon-pulse"></span> /create-ticket
        </button>
        <button type="button" class="bot-btn-action" id="btn-action-ping">
          <span class="icon-pulse"></span> /ping-gateway
        </button>
      </div>
    </div>
  `;

  // Simulator Logic
  const log = container.querySelector('#bot-message-log');
  const gwLatency = container.querySelector('#gw-latency');
  const btnAudit = container.querySelector('#btn-action-audit');
  const btnTicket = container.querySelector('#btn-action-ticket');
  const btnPing = container.querySelector('#btn-action-ping');

  function appendMessage(command, title, content, fields = []) {
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const row = document.createElement('div');
    row.className = 'bot-msg-row fade-in';
    row.innerHTML = `
      <div class="bot-avatar">A</div>
      <div class="bot-msg-content">
        <div class="bot-msg-author">Astral <span class="badge-app">APP</span> <span class="bot-msg-time">Today at ${time}</span> <span class="bot-cmd-tag">${command}</span></div>
        <div class="bot-embed">
          <div class="embed-sidebar"></div>
          <div class="embed-inner">
            <div class="embed-title">${title}</div>
            <div class="embed-desc">${content}</div>
            ${fields.length ? `
              <div class="embed-fields">
                ${fields.map(f => `<div class="embed-field"><div class="ef-label">${f.label}</div><div class="ef-val">${f.val}</div></div>`).join('')}
              </div>
            ` : ''}
          </div>
        </div>
      </div>
    `;
    log.appendChild(row);
    log.scrollTop = log.scrollHeight;
  }

  btnAudit?.addEventListener('click', () => {
    btnAudit.disabled = true;
    setTimeout(() => {
      appendMessage(
        '/run-audit',
        'Security & Permissions Audit Complete',
        'Scanned 14 channels and 6 administrative roles. Hierarchy verified. No leaked webhook secrets detected.',
        [
          { label: 'RISK SCORE', val: '0 (Clean)' },
          { label: 'VERIFIED ROLES', val: '12 / 12' }
        ]
      );
      btnAudit.disabled = false;
    }, 400);
  });

  btnTicket?.addEventListener('click', () => {
    btnTicket.disabled = true;
    const ticketId = 'AST-' + Math.floor(1000 + Math.random() * 9000);
    setTimeout(() => {
      appendMessage(
        '/create-ticket',
        `Private Workspace Generated · [${ticketId}]`,
        'Created isolated thread with restricted staff permissions. Automatic inactivity timer initiated.',
        [
          { label: 'CHANNEL', val: `#ticket-${ticketId}` },
          { label: 'ACCESS TIER', val: 'Verified Staff' }
        ]
      );
      btnTicket.disabled = false;
    }, 450);
  });

  btnPing?.addEventListener('click', () => {
    const lat = Math.floor(14 + Math.random() * 12);
    gwLatency.textContent = `${lat}ms`;
    appendMessage(
      '/ping-gateway',
      'Heartbeat Telemetry Verified',
      `WebSocket roundtrip confirmed in ${lat}ms. REST API endpoint responsive.`,
      [
        { label: 'HEARTBEAT ACK', val: '0 packet loss' },
        { label: 'SHARD ID', val: 'Shard 0/1' }
      ]
    );
  });
}
