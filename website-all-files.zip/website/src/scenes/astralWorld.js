import * as THREE from 'three';

/**
 * Astral Signature 3D World
 * High-precision architectural orbital mechanism with physically-based materials,
 * dynamic spatial waypoints, interactive inspection, and responsive rendering.
 */
export class AstralWorld {
  constructor(canvasElement, options = {}) {
    this.canvas = canvasElement;
    this.options = Object.assign({
      interactive: true,
      enableScrollParallax: true,
      enableHoverResonance: true,
    }, options);

    this.isDisposed = false;
    this.isDragging = false;
    this.inspectMode = false;
    this.exploded = false;
    this.explodeFactor = 0;
    this.targetExplode = 0;

    // Enhanced kinetic & alignment states
    this.surgeFactor = 1.0;
    this.targetSurgeFactor = 1.0;
    this.isAligned = false;
    this.alignFactor = 0;
    this.targetAlign = 0;

    // Mouse / Pointer State
    this.mouse = { x: 0, y: 0, targetX: 0, targetY: 0 };
    this.dragStart = { x: 0, y: 0 };
    this.dragRotation = { x: 0, y: 0, targetX: 0, targetY: 0 };

    // Scroll interpolation
    this.scrollProgress = 0;
    this.targetScrollProgress = 0;

    // Clock
    this.clock = new THREE.Clock();

    this.init();
  }

  init() {
    // WebGL availability check
    try {
      const testCanvas = document.createElement('canvas');
      const gl = testCanvas.getContext('webgl2') || testCanvas.getContext('webgl');
      if (!gl) {
        this.renderFallback();
        return;
      }
    } catch (e) {
      this.renderFallback();
      return;
    }

    try {
      // 1. Renderer Setup
      this.renderer = new THREE.WebGLRenderer({
        canvas: this.canvas,
        antialias: true,
        alpha: true,
        powerPreference: 'high-performance',
      });
      this.renderer.setSize(this.canvas.clientWidth, this.canvas.clientHeight, false);
      this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
      this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
      this.renderer.toneMappingExposure = 1.1;
      this.renderer.outputColorSpace = THREE.SRGBColorSpace;
      this.renderer.shadowMap.enabled = true;
      this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

      // 2. Scene
      this.scene = new THREE.Scene();

      // 3. Camera
      const aspect = this.canvas.clientWidth / this.canvas.clientHeight;
      this.camera = new THREE.PerspectiveCamera(40, aspect, 0.1, 100);
      this.camera.position.set(0, 0, 7.5);

      // 4. Studio Environment Lighting
      this.setupLighting();

      // 5. Construct Signature Astral Orbital Mechanism
      this.mechanismGroup = new THREE.Group();
      this.scene.add(this.mechanismGroup);
      this.buildSculpture();

      // 6. Camera Waypoint Setup
      this.setupCameraWaypoints();

      // 7. Event Listeners
      this.bindEvents();

      // 8. Start Loop
      this.animate = this.animate.bind(this);
      this.rafId = requestAnimationFrame(this.animate);
    } catch (err) {
      console.warn('WebGL initialization failed, switching to architectural fallback:', err);
      this.renderFallback();
    }
  }

  renderFallback() {
    if (!this.canvas || !this.canvas.parentElement) return;
    const parent = this.canvas.parentElement;
    this.canvas.style.display = 'none';
    const fallback = document.createElement('div');
    fallback.style.cssText = 'width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; position: relative;';
    fallback.innerHTML = `
      <svg viewBox="0 0 400 400" style="width: 80%; height: 80%; max-width: 380px; opacity: 0.85;">
        <circle cx="200" cy="200" r="140" fill="none" stroke="#64748b" stroke-width="1.5" stroke-dasharray="4 6" />
        <circle cx="200" cy="200" r="110" fill="none" stroke="#94a3b8" stroke-width="2" />
        <ellipse cx="200" cy="200" rx="140" ry="60" fill="none" stroke="#38bdf8" stroke-width="1.5" transform="rotate(25 200 200)" />
        <ellipse cx="200" cy="200" rx="140" ry="60" fill="none" stroke="#93c5fd" stroke-width="1.5" transform="rotate(-35 200 200)" />
        <polygon points="200,140 250,200 200,260 150,200" fill="none" stroke="#f0f0f2" stroke-width="2" />
        <circle cx="200" cy="200" r="12" fill="#38bdf8" />
      </svg>
    `;
    parent.appendChild(fallback);
  }

  setupLighting() {
    // Ambient fill
    const ambient = new THREE.AmbientLight(0x0e121a, 1.2);
    this.scene.add(ambient);

    // Key Light - Crisp Cool White from top right
    this.keyLight = new THREE.DirectionalLight(0xf0f4f8, 2.8);
    this.keyLight.position.set(5, 7, 6);
    this.keyLight.castShadow = true;
    this.keyLight.shadow.mapSize.width = 1024;
    this.keyLight.shadow.mapSize.height = 1024;
    this.keyLight.shadow.bias = -0.0001;
    this.scene.add(this.keyLight);

    // Rim / Edge Light - Architectural Icy Blue from behind left
    this.rimLight = new THREE.DirectionalLight(0x38bdf8, 2.2);
    this.rimLight.position.set(-6, -3, -5);
    this.scene.add(this.rimLight);

    // Center Core Light - Subtle inner pulse
    this.coreLight = new THREE.PointLight(0x93c5fd, 1.5, 6);
    this.coreLight.position.set(0, 0, 0);
    this.scene.add(this.coreLight);
  }

  buildSculpture() {
    // Architectural metallic materials
    const darkTitaniumMat = new THREE.MeshStandardMaterial({
      color: 0x181a20,
      metalness: 0.88,
      roughness: 0.22,
    });

    const brushedSilverMat = new THREE.MeshStandardMaterial({
      color: 0x94a3b8,
      metalness: 0.92,
      roughness: 0.18,
    });

    const iceChromeMat = new THREE.MeshStandardMaterial({
      color: 0xbae6fd,
      metalness: 0.95,
      roughness: 0.1,
    });

    const sapphireGlassMat = new THREE.MeshPhysicalMaterial({
      color: 0xe0f2fe,
      metalness: 0.1,
      roughness: 0.12,
      transmission: 0.85,
      thickness: 0.6,
      transparent: true,
      opacity: 0.9,
      ior: 1.52,
    });

    // Outer Equatorial Ring (Notched Machined Chassis)
    this.outerRing = new THREE.Group();
    const torusGeo = new THREE.TorusGeometry(2.4, 0.045, 24, 120);
    const torusMesh = new THREE.Mesh(torusGeo, darkTitaniumMat);
    torusMesh.castShadow = true;
    torusMesh.receiveShadow = true;
    this.outerRing.add(torusMesh);

    // Radial measurement lugs on outer ring
    const lugGeo = new THREE.BoxGeometry(0.04, 0.14, 0.08);
    for (let i = 0; i < 24; i++) {
      const angle = (i / 24) * Math.PI * 2;
      const lug = new THREE.Mesh(lugGeo, i % 6 === 0 ? brushedSilverMat : darkTitaniumMat);
      lug.position.set(Math.cos(angle) * 2.4, Math.sin(angle) * 2.4, 0);
      lug.rotation.z = angle;
      this.outerRing.add(lug);
    }
    this.mechanismGroup.add(this.outerRing);

    // Meridian Gimbal Ring (Rotates orthogonally)
    this.meridianRing = new THREE.Group();
    const meridianGeo = new THREE.TorusGeometry(1.95, 0.038, 20, 100);
    const meridianMesh = new THREE.Mesh(meridianGeo, brushedSilverMat);
    meridianMesh.castShadow = true;
    this.meridianRing.add(meridianMesh);

    // Inner guide track bearings
    const bearingGeo = new THREE.SphereGeometry(0.045, 12, 12);
    for (let i = 0; i < 8; i++) {
      const angle = (i / 8) * Math.PI * 2;
      const bearing = new THREE.Mesh(bearingGeo, iceChromeMat);
      bearing.position.set(Math.cos(angle) * 1.95, Math.sin(angle) * 1.95, 0);
      this.meridianRing.add(bearing);
    }
    this.meridianRing.rotation.x = Math.PI / 3;
    this.mechanismGroup.add(this.meridianRing);

    // Brand homage: Eccentric Astral Arc & Carrier
    this.eccentricArc = new THREE.Group();
    const arcGeo = new THREE.TorusGeometry(1.5, 0.032, 16, 80, Math.PI * 1.35);
    const arcMesh = new THREE.Mesh(arcGeo, iceChromeMat);
    this.eccentricArc.add(arcMesh);
    this.eccentricArc.rotation.y = Math.PI / 4;
    this.eccentricArc.rotation.z = Math.PI / 6;
    this.mechanismGroup.add(this.eccentricArc);

    // Translucent Sapphire Optical Disc (Refractive layer)
    this.discGroup = new THREE.Group();
    const discGeo = new THREE.CylinderGeometry(1.2, 1.2, 0.02, 64);
    const discMesh = new THREE.Mesh(discGeo, sapphireGlassMat);
    discMesh.rotation.x = Math.PI / 2;
    this.discGroup.add(discMesh);
    this.mechanismGroup.add(this.discGroup);

    // Central Astral Polyhedron / Core Engine
    this.coreNode = new THREE.Group();
    
    // Outer faceted cage: Octahedron
    const cageGeo = new THREE.OctahedronGeometry(0.72, 0);
    const cageWireGeo = new THREE.WireframeGeometry(cageGeo);
    const cageWireMat = new THREE.LineBasicMaterial({ color: 0x93c5fd, transparent: true, opacity: 0.65 });
    const cageWire = new THREE.LineSegments(cageWireGeo, cageWireMat);
    this.coreNode.add(cageWire);

    // Inner solid machined nucleus: Icosahedron
    const nucleusGeo = new THREE.IcosahedronGeometry(0.48, 0);
    this.nucleusMesh = new THREE.Mesh(nucleusGeo, brushedSilverMat);
    this.coreNode.add(this.nucleusMesh);

    // Astral 4-point star beacon in the center
    const starShape = new THREE.Shape();
    const outerR = 0.35;
    const innerR = 0.1;
    for (let i = 0; i < 8; i++) {
      const r = i % 2 === 0 ? outerR : innerR;
      const a = (i / 8) * Math.PI * 2;
      const x = Math.cos(a) * r;
      const y = Math.sin(a) * r;
      if (i === 0) starShape.moveTo(x, y);
      else starShape.lineTo(x, y);
    }
    starShape.closePath();
    const starExtrude = new THREE.ExtrudeGeometry(starShape, { depth: 0.05, bevelEnabled: true, bevelThickness: 0.02, bevelSize: 0.02, bevelSegments: 3 });
    const starMesh = new THREE.Mesh(starExtrude, iceChromeMat);
    starMesh.position.z = -0.025;
    this.coreNode.add(starMesh);

    this.mechanismGroup.add(this.coreNode);

    // Revolving Keplerian Nodes & Telemetry Beacons
    this.satelliteGroup = new THREE.Group();
    const satGeo = new THREE.CylinderGeometry(0.04, 0.04, 0.12, 16);
    this.satellites = [];
    const satDistances = [2.8, 3.2, 3.6];

    for (let i = 0; i < 3; i++) {
      const sat = new THREE.Mesh(satGeo, brushedSilverMat);
      sat.userData = {
        distance: satDistances[i],
        speed: 0.4 + i * 0.25,
        tilt: (i - 1) * 0.35,
        phase: (i * Math.PI * 2) / 3,
      };
      this.satelliteGroup.add(sat);
      this.satellites.push(sat);

      // Fine coordinate tracer ring
      const orbitRingGeo = new THREE.TorusGeometry(satDistances[i], 0.005, 8, 80);
      const orbitRingMat = new THREE.LineBasicMaterial({ color: 0x475569, transparent: true, opacity: 0.25 });
      const orbitRing = new THREE.Line(orbitRingGeo, orbitRingMat);
      orbitRing.rotation.x = sat.userData.tilt;
      this.satelliteGroup.add(orbitRing);
    }
    this.mechanismGroup.add(this.satelliteGroup);

    // Fine Ambient Dust / Constellation Points (restrained, 120 points only)
    const dustCount = 120;
    const dustPositions = new Float32Array(dustCount * 3);
    for (let i = 0; i < dustCount; i++) {
      dustPositions[i * 3 + 0] = (Math.random() - 0.5) * 14;
      dustPositions[i * 3 + 1] = (Math.random() - 0.5) * 10;
      dustPositions[i * 3 + 2] = (Math.random() - 0.5) * 8;
    }
    const dustGeo = new THREE.BufferGeometry();
    dustGeo.setAttribute('position', new THREE.BufferAttribute(dustPositions, 3));
    const dustMat = new THREE.PointsMaterial({
      color: 0x94a3b8,
      size: 0.035,
      transparent: true,
      opacity: 0.4,
    });
    this.dustParticles = new THREE.Points(dustGeo, dustMat);
    this.scene.add(this.dustParticles);
  }

  setupCameraWaypoints() {
    // Spatial Waypoints corresponding to page progression
    this.waypoints = [
      { z: 7.5, x: 0.8, y: 0.2, rx: 0.05, ry: 0.2 },    // Hero: slightly offset right
      { z: 6.8, x: -0.6, y: -0.2, rx: 0.25, ry: -0.3 },  // Services: tilted inspection
      { z: 7.2, x: 0, y: 0.4, rx: 0.35, ry: 0.1 },       // Process: exploded axial view
      { z: 6.2, x: 0, y: 0, rx: 0, ry: 0 },              // Contact: synchronized focal view
    ];
  }

  bindEvents() {
    this.onResize = this.onResize.bind(this);
    this.onPointerMove = this.onPointerMove.bind(this);
    this.onPointerDown = this.onPointerDown.bind(this);
    this.onPointerUp = this.onPointerUp.bind(this);
    this.onScroll = this.onScroll.bind(this);

    window.addEventListener('resize', this.onResize);
    window.addEventListener('scroll', this.onScroll, { passive: true });

    if (this.options.interactive) {
      window.addEventListener('pointermove', this.onPointerMove, { passive: true });
      this.canvas.addEventListener('pointerdown', this.onPointerDown);
      window.addEventListener('pointerup', this.onPointerUp);
    }
  }

  onResize() {
    if (!this.canvas || this.isDisposed) return;
    const width = this.canvas.clientWidth;
    const height = this.canvas.clientHeight;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height, false);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  }

  onPointerMove(e) {
    if (this.isDragging) {
      const deltaX = (e.clientX - this.dragStart.x) * 0.006;
      const deltaY = (e.clientY - this.dragStart.y) * 0.006;
      this.dragRotation.targetY += deltaX;
      this.dragRotation.targetX += deltaY;
      this.dragStart = { x: e.clientX, y: e.clientY };
    } else {
      // Subtle parallax response
      const nx = (e.clientX / window.innerWidth) * 2 - 1;
      const ny = -(e.clientY / window.innerHeight) * 2 + 1;
      this.mouse.targetX = nx * 0.35;
      this.mouse.targetY = ny * 0.25;
    }
  }

  onPointerDown(e) {
    this.isDragging = true;
    this.dragStart = { x: e.clientX, y: e.clientY };
  }

  onPointerUp() {
    this.isDragging = false;
  }

  onScroll() {
    if (!this.options.enableScrollParallax) return;
    const maxScroll = document.documentElement.scrollHeight - window.innerHeight;
    if (maxScroll <= 0) return;
    this.targetScrollProgress = Math.min(Math.max(window.scrollY / maxScroll, 0), 1);
  }

  triggerExplodeToggle() {
    this.exploded = !this.exploded;
    this.targetExplode = this.exploded ? 1 : 0;
    return this.exploded;
  }

  triggerResonance() {
    // Pulse light and quick speed shift
    this.coreLight.intensity = 4.0;
    setTimeout(() => {
      if (!this.isDisposed) this.coreLight.intensity = 1.5;
    }, 400);
  }

  triggerSurge() {
    // Kinetic surge: Accelerates rings rapidly then decays
    this.surgeFactor = 4.2;
    this.targetSurgeFactor = 1.0;
    this.triggerResonance();
    return true;
  }

  triggerAlign() {
    this.isAligned = !this.isAligned;
    this.targetAlign = this.isAligned ? 1 : 0;
    return this.isAligned;
  }

  animate() {
    if (this.isDisposed) return;
    this.rafId = requestAnimationFrame(this.animate);

    const delta = this.clock.getDelta();
    const elapsedTime = this.clock.getElapsedTime();

    // Smooth lerps
    this.mouse.x += (this.mouse.targetX - this.mouse.x) * 0.06;
    this.mouse.y += (this.mouse.targetY - this.mouse.y) * 0.06;

    this.dragRotation.x += (this.dragRotation.targetX - this.dragRotation.x) * 0.1;
    this.dragRotation.y += (this.dragRotation.targetY - this.dragRotation.y) * 0.1;

    this.scrollProgress += (this.targetScrollProgress - this.scrollProgress) * 0.05;
    this.explodeFactor += (this.targetExplode - this.explodeFactor) * 0.08;
    this.surgeFactor += (this.targetSurgeFactor - this.surgeFactor) * 0.04;
    this.alignFactor += (this.targetAlign - this.alignFactor) * 0.06;

    // Specular light responds dynamically to pointer
    if (this.keyLight) {
      this.keyLight.position.x = 5 + this.mouse.x * 2.5;
      this.keyLight.position.y = 7 + this.mouse.y * 2.5;
    }

    // Gentle architectural zero-gravity floating
    this.mechanismGroup.position.y = Math.sin(elapsedTime * 1.1) * 0.08;

    // Harmonic mechanical rotations with surge factor
    const baseSpeed = 0.25 * this.surgeFactor;
    this.outerRing.rotation.z = elapsedTime * baseSpeed * 0.5;

    // Normal gimbal tilt or planar aligned orientation
    const normalMeridianTilt = (Math.PI / 3) + Math.sin(elapsedTime * 0.4) * 0.15;
    const alignedMeridianTilt = Math.PI / 2;
    this.meridianRing.rotation.x = normalMeridianTilt * (1 - this.alignFactor) + alignedMeridianTilt * this.alignFactor;
    this.meridianRing.rotation.y = elapsedTime * baseSpeed * 0.8;

    this.eccentricArc.rotation.z = -elapsedTime * baseSpeed * 1.1;
    this.discGroup.rotation.z = elapsedTime * baseSpeed * 0.3;

    // Core breathing
    const pulse = 1 + Math.sin(elapsedTime * 2.2) * 0.04;
    this.nucleusMesh.scale.set(pulse, pulse, pulse);
    this.coreNode.rotation.y = elapsedTime * baseSpeed * 1.4;
    this.coreNode.rotation.x = Math.sin(elapsedTime * 0.8) * 0.2;

    // Satellites orbital positioning
    this.satellites.forEach((sat) => {
      const d = sat.userData.distance;
      const angle = elapsedTime * (sat.userData.speed * this.surgeFactor) + sat.userData.phase;
      sat.position.x = Math.cos(angle) * d;
      sat.position.y = Math.sin(angle) * d * Math.cos(sat.userData.tilt);
      sat.position.z = Math.sin(angle) * d * Math.sin(sat.userData.tilt);
      sat.rotation.z = angle;
    });

    // Ambient constellation dust subtle drift
    if (this.dustParticles) {
      this.dustParticles.rotation.y = elapsedTime * 0.03;
      this.dustParticles.rotation.x = Math.sin(elapsedTime * 0.05) * 0.05;
    }

    // Exploded view separation
    this.outerRing.position.z = this.explodeFactor * 0.9;
    this.meridianRing.position.z = -this.explodeFactor * 0.8;
    this.discGroup.position.y = this.explodeFactor * 0.6;
    this.coreNode.position.z = this.explodeFactor * 0.4;

    // Apply Drag & Parallax Orientation to Master Mechanism Group
    this.mechanismGroup.rotation.y = this.dragRotation.y + this.mouse.x * 0.5;
    this.mechanismGroup.rotation.x = this.dragRotation.x - this.mouse.y * 0.4;

    // Camera waypoint interpolation along scroll
    if (this.options.enableScrollParallax && this.waypoints.length >= 2) {
      const idx = Math.min(this.scrollProgress * (this.waypoints.length - 1), this.waypoints.length - 1.001);
      const currIdx = Math.floor(idx);
      const nextIdx = Math.min(currIdx + 1, this.waypoints.length - 1);
      const frac = idx - currIdx;

      const wpCurr = this.waypoints[currIdx];
      const wpNext = this.waypoints[nextIdx];

      const targetCamX = wpCurr.x + (wpNext.x - wpCurr.x) * frac;
      const targetCamY = wpCurr.y + (wpNext.y - wpCurr.y) * frac;
      const targetCamZ = wpCurr.z + (wpNext.z - wpCurr.z) * frac;

      this.camera.position.x += (targetCamX - this.camera.position.x) * 0.08;
      this.camera.position.y += (targetCamY - this.camera.position.y) * 0.08;
      this.camera.position.z += (targetCamZ - this.camera.position.z) * 0.08;
      this.camera.lookAt(0, 0, 0);
    }

    // Render frame
    this.renderer.render(this.scene, this.camera);
  }

  dispose() {
    this.isDisposed = true;
    cancelAnimationFrame(this.rafId);

    window.removeEventListener('resize', this.onResize);
    window.removeEventListener('scroll', this.onScroll);
    window.removeEventListener('pointermove', this.onPointerMove);
    window.removeEventListener('pointerup', this.onPointerUp);

    // Dispose geometries, materials, and renderer
    this.scene.traverse((child) => {
      if (child.isMesh || child.isLine || child.isPoints) {
        if (child.geometry) child.geometry.dispose();
        if (child.material) {
          if (Array.isArray(child.material)) {
            child.material.forEach((m) => m.dispose());
          } else {
            child.material.dispose();
          }
        }
      }
    });

    if (this.renderer) {
      this.renderer.dispose();
      this.renderer.forceContextLoss();
    }
  }
}
