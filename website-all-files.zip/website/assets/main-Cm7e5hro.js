import{t as e}from"./navigation-dctseuWk.js";import{t}from"./astralWorld-B84sCvUs.js";function n(e){let t=document.getElementById(e);if(!t)return;t.innerHTML=`
    <div class="bot-terminal-card">
      <div class="bot-terminal-header">
        <div class="bot-status-indicator">
          <span class="bot-dot"></span>
          <span class="bot-name">ASTRAL CORE NODE</span>
          <span class="bot-tag">v2.4.1</span>
        </div>
        <div class="bot-telemetry">
          <span class="telemetry-item">GATEWAY: <strong id="gw-latency">18ms</strong></span>
          <span class="telemetry-item">UPTIME: <strong>99.98%</strong></span>
        </div>
      </div>

      <div class="bot-terminal-body" id="bot-message-log">
        <div class="bot-msg-row">
          <div class="bot-avatar">A</div>
          <div class="bot-msg-content">
            <div class="bot-msg-author">Astral <span class="badge-app">APP</span> <span class="bot-msg-time">Today at 14:30</span></div>
            <div class="bot-embed">
              <div class="embed-sidebar"></div>
              <div class="embed-inner">
                <div class="embed-title">Operational Status · Cluster [eu-central-01]</div>
                <div class="embed-desc">All shard connections stable. Automated queue dispatcher listening on socket #6102.</div>
                <div class="embed-fields">
                  <div class="embed-field"><div class="ef-label">ACTIVE GUILDS</div><div class="ef-val">48 Communities</div></div>
                  <div class="embed-field"><div class="ef-label">PIPELINE</div><div class="ef-val">0 Tasks Queued</div></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="bot-actions-bar">
        <button type="button" class="bot-btn-action" id="btn-action-audit">
          <span class="icon-pulse"></span> /run-audit
        </button>
        <button type="button" class="bot-btn-action" id="btn-action-ticket">
          <span class="icon-pulse"></span> /create-ticket
        </button>
        <button type="button" class="bot-btn-action" id="btn-action-ping">
          <span class="icon-pulse"></span> /ping-gateway
        </button>
      </div>
    </div>
  `;let n=t.querySelector(`#bot-message-log`),r=t.querySelector(`#gw-latency`),i=t.querySelector(`#btn-action-audit`),a=t.querySelector(`#btn-action-ticket`),o=t.querySelector(`#btn-action-ping`);function s(e,t,r,i=[]){let a=new Date().toLocaleTimeString([],{hour:`2-digit`,minute:`2-digit`}),o=document.createElement(`div`);o.className=`bot-msg-row fade-in`,o.innerHTML=`
      <div class="bot-avatar">A</div>
      <div class="bot-msg-content">
        <div class="bot-msg-author">Astral <span class="badge-app">APP</span> <span class="bot-msg-time">Today at ${a}</span> <span class="bot-cmd-tag">${e}</span></div>
        <div class="bot-embed">
          <div class="embed-sidebar"></div>
          <div class="embed-inner">
            <div class="embed-title">${t}</div>
            <div class="embed-desc">${r}</div>
            ${i.length?`
              <div class="embed-fields">
                ${i.map(e=>`<div class="embed-field"><div class="ef-label">${e.label}</div><div class="ef-val">${e.val}</div></div>`).join(``)}
              </div>
            `:``}
          </div>
        </div>
      </div>
    `,n.appendChild(o),n.scrollTop=n.scrollHeight}i?.addEventListener(`click`,()=>{i.disabled=!0,setTimeout(()=>{s(`/run-audit`,`Security & Permissions Audit Complete`,`Scanned 14 channels and 6 administrative roles. Hierarchy verified. No leaked webhook secrets detected.`,[{label:`RISK SCORE`,val:`0 (Clean)`},{label:`VERIFIED ROLES`,val:`12 / 12`}]),i.disabled=!1},400)}),a?.addEventListener(`click`,()=>{a.disabled=!0;let e=`AST-`+Math.floor(1e3+Math.random()*9e3);setTimeout(()=>{s(`/create-ticket`,`Private Workspace Generated · [${e}]`,`Created isolated thread with restricted staff permissions. Automatic inactivity timer initiated.`,[{label:`CHANNEL`,val:`#ticket-${e}`},{label:`ACCESS TIER`,val:`Verified Staff`}]),a.disabled=!1},450)}),o?.addEventListener(`click`,()=>{let e=Math.floor(14+Math.random()*12);r.textContent=`${e}ms`,s(`/ping-gateway`,`Heartbeat Telemetry Verified`,`WebSocket roundtrip confirmed in ${e}ms. REST API endpoint responsive.`,[{label:`HEARTBEAT ACK`,val:`0 packet loss`},{label:`SHARD ID`,val:`Shard 0/1`}])})}e(),n(`home-discord-simulator`);var r=document.getElementById(`hero-3d-canvas`);if(r){let e=new t(r,{interactive:!0,enableScrollParallax:!0}),n=document.getElementById(`btn-toggle-explode`);n?.addEventListener(`click`,()=>{let t=e.triggerExplodeToggle();n.classList.toggle(`is-active`,t)});let i=document.getElementById(`btn-trigger-pulse`);i?.addEventListener(`click`,()=>{e.triggerResonance(),i.classList.add(`is-active`),setTimeout(()=>i.classList.remove(`is-active`),500)})}