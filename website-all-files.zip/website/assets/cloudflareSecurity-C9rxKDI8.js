var e=class{static initTurnstile(e,t={}){let n=document.getElementById(e);if(!n)return null;let r=!1,i=``,a=t.onVerify||(()=>{}),o=`8f${Math.floor(1e7+Math.random()*9e7).toString(16)}`,s=t.edgeNode||`DHK01 · Edge Core`;n.innerHTML=`
      <div class="cf-turnstile-box" role="region" aria-label="Cloudflare Security Verification">
        <div class="cf-turnstile-content">
          <div class="cf-checkbox-wrapper">
            <button type="button" class="cf-checkbox-btn" id="cf-verify-btn" aria-label="Verify you are human with Cloudflare Turnstile">
              <span class="cf-box-border"></span>
              <span class="cf-spinner"></span>
              <svg class="cf-checkmark" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="20 6 9 17 4 12"></polyline>
              </svg>
            </button>
            <span class="cf-prompt-text" id="cf-prompt-label">Verify you are human</span>
          </div>

          <div class="cf-branding">
            <div class="cf-logo-row">
              <svg class="cf-cloud-logo" viewBox="0 0 48 32" fill="none">
                <path d="M38.8 14.2C37.4 9.4 32.8 6 27.5 6c-4.8 0-9.1 2.9-10.8 7.2-1-.4-2-.6-3.1-.6-4.6 0-8.4 3.7-8.4 8.3 0 .4 0 .7.1 1.1C2.2 22.8 0 25.4 0 28.5 0 32.1 2.9 35 6.5 35h32.2c4.6 0 8.3-3.7 8.3-8.3 0-5.1-3.6-9.4-8.2-12.5z" fill="#F38020"/>
                <path d="M38.7 26.7h-9.9c-.6 0-1-.4-1-1v-4.4c0-.6.4-1 1-1h9.9c2.3 0 4.1 1.9 4.1 4.1 0 2.3-1.8 2.3-4.1 2.3z" fill="#FAAD3F"/>
              </svg>
              <span class="cf-brand-name">Cloudflare</span>
            </div>
            <div class="cf-terms-links">
              <span>Turnstile</span>
              <span class="cf-dot-sep">·</span>
              <a href="https://www.cloudflare.com/privacypolicy/" target="_blank" rel="noopener">Privacy</a>
              <span class="cf-dot-sep">·</span>
              <a href="https://www.cloudflare.com/website-terms/" target="_blank" rel="noopener">Terms</a>
            </div>
          </div>
        </div>

        <div class="cf-telemetry-strip" id="cf-telemetry-info" style="display: none;">
          <span class="cf-telemetry-badge">EDGE SHIELD ACTIVE</span>
          <span class="cf-telemetry-item">RAY ID: <strong>${o}</strong></span>
          <span class="cf-telemetry-item">NODE: <strong>${s}</strong></span>
          <span class="cf-telemetry-item">STATUS: <strong style="color: #22c55e;">PASSED</strong></span>
        </div>
      </div>
    `;let c=n.querySelector(`#cf-verify-btn`),l=n.querySelector(`#cf-prompt-label`),u=n.querySelector(`#cf-telemetry-info`);return c?.addEventListener(`click`,()=>{r||c.classList.contains(`is-checking`)||(c.classList.add(`is-checking`),l.textContent=`Verifying browser integrity...`,setTimeout(()=>{r=!0,i=`0.CF.sec_${Math.random().toString(36).substring(2,15)}_${Date.now()}`,c.classList.remove(`is-checking`),c.classList.add(`is-verified`),l.textContent=`Success! Verified human visitor`,l.style.color=`#f0f0f2`,l.style.fontWeight=`600`,u.style.display=`flex`,a({verified:!0,token:i,rayId:o,edgeNode:s})},700))}),{isVerified:()=>r,getToken:()=>i,reset:()=>{r=!1,i=``,c?.classList.remove(`is-checking`,`is-verified`),l&&(l.textContent=`Verify you are human`),u&&(u.style.display=`none`)}}}static initEdgeSecuritySimulator(e){let t=document.getElementById(e);if(!t)return;t.innerHTML=`
      <div class="cf-security-card">
        <div class="cf-sec-header">
          <div class="cf-sec-status">
            <span class="cf-pulse-orange"></span>
            <div>
              <div class="cf-sec-title">CLOUDFLARE EDGE DEFENSE MATRIX</div>
              <div class="cf-sec-sub">Layer 7 DDoS Shield · WAF Ruleset v4.8 · Edge Workers Active</div>
            </div>
          </div>
          <div class="cf-sec-badges">
            <span class="cf-sec-pill">330+ CITIES</span>
            <span class="cf-sec-pill accent">ZERO TRUST ACTIVE</span>
          </div>
        </div>

        <div class="cf-sec-body">
          <div class="cf-stats-row">
            <div class="cf-stat-unit">
              <div class="cf-unit-lbl">EDGE INGRESS LATENCY</div>
              <div class="cf-unit-val" id="cf-edge-lat">1.4ms</div>
            </div>
            <div class="cf-stat-unit">
              <div class="cf-unit-lbl">THREAT MITIGATION</div>
              <div class="cf-unit-val" style="color: #22c55e;" id="cf-edge-mitigated">100% BLOCKED</div>
            </div>
            <div class="cf-stat-unit">
              <div class="cf-unit-lbl">BOT CHALLENGE MODE</div>
              <div class="cf-unit-val" id="cf-edge-mode">Turnstile Silent</div>
            </div>
            <div class="cf-stat-unit">
              <div class="cf-unit-lbl">DISCORD ORIGIN SHARD LOAD</div>
              <div class="cf-unit-val" id="cf-edge-load">0.2% Normal</div>
            </div>
          </div>

          <div class="cf-terminal-feed" id="cf-security-feed">
            <div class="cf-log-line ok"><span class="cf-time">[14:28:01]</span> [CF-EDGE-WAF] Rule 100284: Discord Webhook signature verification verified at edge.</div>
            <div class="cf-log-line ok"><span class="cf-time">[14:28:12]</span> [CF-TURNSTILE] Token validation passed for client in Dhaka (DHK01) - Ray: 8f94101</div>
            <div class="cf-log-line info"><span class="cf-time">[14:28:24]</span> [CF-DDOS] Anycast route telemetry synchronised across 330 data centers. Zero packet drop.</div>
          </div>

          <div class="cf-sec-actions">
            <button type="button" class="cf-sec-btn" id="btn-cf-flood">
              <span>⚡ Simulate Layer 7 Flood (5,000 req/s)</span>
            </button>
            <button type="button" class="cf-sec-btn" id="btn-cf-injection">
              <span>🛡️ Test Malicious Payload Filter</span>
            </button>
            <button type="button" class="cf-sec-btn" id="btn-cf-reset">
              <span>↺ Reset Stream</span>
            </button>
          </div>
        </div>
      </div>
    `;let n=t.querySelector(`#cf-security-feed`),r=t.querySelector(`#cf-edge-mitigated`),i=t.querySelector(`#cf-edge-load`),a=t.querySelector(`#cf-edge-lat`),o=t.querySelector(`#btn-cf-flood`),s=t.querySelector(`#btn-cf-injection`),c=t.querySelector(`#btn-cf-reset`);function l(e,t){let r=new Date().toLocaleTimeString([],{hour:`2-digit`,minute:`2-digit`,second:`2-digit`}),i=document.createElement(`div`);i.className=`cf-log-line ${e} cf-fade-in`,i.innerHTML=`<span class="cf-time">[${r}]</span> ${t}`,n.appendChild(i),n.scrollTop=n.scrollHeight}o?.addEventListener(`click`,()=>{o.disabled=!0,r.textContent=`INTERCEPTING...`,r.style.color=`#f59e0b`,l(`warn`,`[CF-ATTACK-SIM] Ingress spike detected: 5,420 req/s to /api/discord/webhook`),setTimeout(()=>{l(`alert`,`[CF-WAF-DEFENSE] Adaptive Rate Limiting engaged: IP subnet clustered & challenged.`),l(`ok`,`[CF-WAF-DEFENSE] 5,419 malicious requests dropped at Edge. 1 clean webhook delivered to Discord bot origin in 1.8ms.`),r.textContent=`99.98% BLOCKED AT EDGE`,r.style.color=`#22c55e`,i.textContent=`0.3% (Unaffected)`,a.textContent=`1.8ms`,o.disabled=!1},600)}),s?.addEventListener(`click`,()=>{s.disabled=!0,l(`warn`,`[CF-INSPECT] Inbound POST body contained suspicious payload pattern.`),setTimeout(()=>{l(`alert`,`[CF-WAF-BLOCK] Rule 100042 (Discord Bot Ingress Filter): Sanitized and discarded before origin.`),l(`ok`,`[CF-TELEMETRY] Bot container untouched. Threat signature cached across global edge.`),s.disabled=!1},500)}),c?.addEventListener(`click`,()=>{n.innerHTML=`
        <div class="cf-log-line ok"><span class="cf-time">[14:28:01]</span> [CF-EDGE-WAF] Cloudflare Edge Security online. All 330+ PoPs synchronised.</div>
      `,r.textContent=`100% BLOCKED`,r.style.color=`#22c55e`,i.textContent=`0.2% Normal`,a.textContent=`1.4ms`})}};export{e as t};